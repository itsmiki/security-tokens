from time import sleep
import subprocess


def start_server(console: bool, port: int) -> int:
    if console == 1:
        proc = subprocess.Popen('python server.py ' + str(port), creationflags=subprocess.CREATE_NEW_CONSOLE)
    else:
        proc = subprocess.Popen('python server.py ' + str(port))

    return proc.pid

def stop_server(pid: int) -> int:
    import psutil

    parent = psutil.Process(pid)
    for child in parent.children(recursive=True):  # or parent.children() for recursive=False
        child.kill()
    parent.kill()

# pid = start_server(1, 5000)
# sleep(5)
# stop_server(pid)
# # pid = start_server(0, 8080)
# # sleep(5)
# # stop_server(pid)